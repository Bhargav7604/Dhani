// Violates `no-console`
console.log("Testing global lint rules for admin");

// Violates `@typescript-eslint/no-explicit-any`
// const anyVar: any = "This should trigger a warning";
const Test = () => {
  return <div>Test Global</div>;
};

export default Test;
