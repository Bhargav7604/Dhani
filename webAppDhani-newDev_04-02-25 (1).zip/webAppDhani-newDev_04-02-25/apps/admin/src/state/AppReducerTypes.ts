
export interface AppStateModal {
    example: boolean;
}