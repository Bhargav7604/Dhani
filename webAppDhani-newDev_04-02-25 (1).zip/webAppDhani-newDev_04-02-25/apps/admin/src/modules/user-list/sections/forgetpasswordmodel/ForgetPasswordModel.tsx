import React, { useEffect } from "react";
import { useForm, SubmitHandler } from "react-hook-form";
import { DialogActions } from "@mui/material";
import { CustomButton, FormWrapper } from "../../../../styles/FormStyles";
import {
  AdminModalTitle,
  FlexRow,
  FlexRowDivModal,
} from "./ForgetPasswordModelStyles";
import CustomModalSkeleton from "../../../sharedComponents/CustomModal/CustomModalSkeleton";
import { EditStrategyFormFields } from "./ForgetPasswordModelSpece";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";

import { EditStrategyModalProps } from "../../UsersDataUtils";
import AdminInputComp from "../../../../components/admininput/AdminInputComp";

const EditFormSchema = z
  .object({
    newpassword: z
      .string()
      .min(8, "Password must be at least 8 characters long")
      .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
      .regex(/[a-z]/, "Password must contain at least one lowercase letter")
      .regex(/[0-9]/, "Password must contain at least one number")
      .regex(
        /[@$!%*?&]/,
        "Password must contain at least one special character"
      ),
    reenterpassword: z.string(),
  })
  .refine((data) => data.newpassword === data.reenterpassword, {
    message: "Passwords do not match",
    path: ["reenterpassword"], // Error will be shown for reenterpassword field
  });
type EditStrategySchemaZod = z.infer<typeof EditFormSchema>;

const RenameUserModel: React.FC<EditStrategyModalProps> = ({
  open,
  handleClose,
}) => {
  const {
    control,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<EditStrategySchemaZod>({
    resolver: zodResolver(EditFormSchema),
  });

  // Reset the form whenever the modal is reopened
  useEffect(() => {
    if (open) {
      reset();
    }
  }, [open, reset]);

  const handleCancel = () => {
    reset();
    handleClose();
  };

  const onSubmit: SubmitHandler<EditStrategySchemaZod> = (data) => {
    console.log("Form submitted:", data);
  };
  return (
    <CustomModalSkeleton open={open} handleClose={handleClose}>
      <AdminModalTitle> Change Password</AdminModalTitle>
      <FormWrapper>
        <form onSubmit={handleSubmit(onSubmit)}>
          <FlexRow>
            {EditStrategyFormFields.map((field) => (
              <div key={field.name} style={{ width: "100%" }}>
                <AdminInputComp
                  name={field.name}
                  control={control}
                  heading={field.heading}
                  type={field.type}
                  placeholder={field.placeholder}
                  error={
                    errors[field.name as keyof z.infer<typeof EditFormSchema>]
                      ?.message
                  }
                />
              </div>
            ))}
          </FlexRow>

          <FlexRowDivModal>
            <DialogActions>
              <CustomButton variant="contained" onClick={handleCancel}>
                Cancel
              </CustomButton>
            </DialogActions>
            <DialogActions>
              <CustomButton variant="contained" type="submit" profile>
                Create
              </CustomButton>
            </DialogActions>
          </FlexRowDivModal>
        </form>
      </FormWrapper>
    </CustomModalSkeleton>
  );
};

export default RenameUserModel;
