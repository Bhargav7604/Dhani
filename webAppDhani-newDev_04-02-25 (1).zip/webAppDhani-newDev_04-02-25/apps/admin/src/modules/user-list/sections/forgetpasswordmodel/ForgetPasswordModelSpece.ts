import { z } from "zod";

// Define Zod schema for validation
export const schema = z
  .object({
    newpassword: z
      .string()
      .min(8, "Password must be at least 8 characters long")
      .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
      .regex(/[a-z]/, "Password must contain at least one lowercase letter")
      .regex(/[0-9]/, "Password must contain at least one number")
      .regex(
        /[@$!%*?&]/,
        "Password must contain at least one special character"
      ),
    reenterpassword: z.string(),
  })
  .refine((data) => data.newpassword === data.reenterpassword, {
    message: "Passwords do not match",
    path: ["reenterpassword"], // Error will be shown for reenterpassword field
  });

// Enum for field names
export const StrategyFields = {
  NEWPASSWORD: "newpassword",
  REENTERPASSWORD: "reenterpassword",
};

export const EditStrategyFormMapping = {
  [StrategyFields.NEWPASSWORD]: {
    name: "newpassword",
    type: "password",
    placeholder: "Enter Password",
    heading: "New Password",
    component: "AdminInput",
  },
  [StrategyFields.REENTERPASSWORD]: {
    name: "reenterpassword",
    type: "password",
    placeholder: "Re-Enter Password",
    heading: "Re-Enter Password",
    component: "AdminInput",
  },
};

// Export array to be used in the form component
export const EditStrategyFormFields = [
  EditStrategyFormMapping[StrategyFields.NEWPASSWORD],
  EditStrategyFormMapping[StrategyFields.REENTERPASSWORD],
];
