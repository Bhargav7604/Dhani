export const columns = [
  { field: "userId", headerName: "User ID", flex: 1 },
  { field: "userName", headerName: "User Name", flex: 1 },
  { field: "totalTrades", headerName: "Trade ID", flex: 1 },
  { field: "totalQuantity", headerName: "Quantity", flex: 1 },
  { field: "totalPrice", headerName: "Value", flex: 1 },
];



  