export interface WeightProps {
  fontWeight?: boolean;
}
