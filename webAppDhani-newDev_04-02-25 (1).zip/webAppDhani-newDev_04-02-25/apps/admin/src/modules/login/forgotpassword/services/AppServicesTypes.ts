export interface ForgotPasswordPostProps {
    payload: {
      email: string;
    };
  }