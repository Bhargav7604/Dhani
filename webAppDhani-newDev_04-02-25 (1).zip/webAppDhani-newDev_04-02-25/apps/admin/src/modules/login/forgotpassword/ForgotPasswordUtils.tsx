export interface HeadingProps {
  subHeading?: boolean;
}
