export interface LoginPostProps {
    payload: {
      username: string;
      password: string;
    };
  }