import React from 'react';

export interface AuthLayoutProps {
    children: React.ReactNode;
    imageSrc?: string;
}
