export interface OtpPostProps {
    payload: {
      email: string;
      otp: string;
    };
  }