
export interface DashboardStateModal {
    example: boolean
}