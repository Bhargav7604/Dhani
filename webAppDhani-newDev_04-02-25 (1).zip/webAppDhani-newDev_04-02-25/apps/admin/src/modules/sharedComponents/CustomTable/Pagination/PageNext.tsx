
export default function PageNext() {
  return (
    <div>
      Next
    </div>
  )
}
