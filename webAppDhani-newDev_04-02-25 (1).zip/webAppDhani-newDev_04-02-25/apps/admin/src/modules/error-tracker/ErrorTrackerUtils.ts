export interface ErrorTrakerRows {
  id: number;
  strategyId: string;
  strategyName: string;
  userId: string;
  deploymentDate: string;
  description: string;
  status: string;
  errorCode: string;
}
