import EditDIYForm from "../edit-diy-form/EditDIYForm";

function CreateOwnStrategy() {
  return    <EditDIYForm />;
}

export default CreateOwnStrategy;
