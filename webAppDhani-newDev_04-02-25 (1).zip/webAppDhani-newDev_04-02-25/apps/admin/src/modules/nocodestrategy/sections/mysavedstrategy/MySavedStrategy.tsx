import EditDIYForm from "../edit-diy-form/EditDIYForm";

function MySavedStrategy() {
  return <EditDIYForm />;
}

export default MySavedStrategy;
