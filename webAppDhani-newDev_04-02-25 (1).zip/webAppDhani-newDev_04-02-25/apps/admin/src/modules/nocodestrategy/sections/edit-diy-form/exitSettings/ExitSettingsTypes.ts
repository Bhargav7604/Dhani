export interface stateType {
  shimmer?: boolean;
}
