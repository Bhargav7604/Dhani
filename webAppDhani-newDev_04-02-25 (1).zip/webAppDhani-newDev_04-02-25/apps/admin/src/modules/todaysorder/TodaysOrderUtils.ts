export interface TodayOrderTypes {
  id: string;
  orderUniqueIdentifier: string;
  userId: string;
  userName: string;
  strategyId: number;
  strategyName: string;
  dateTime: number;
  symbol: string;
  quantity: string;
  price: string;
  status: string;
}
