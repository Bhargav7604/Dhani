import { HeadingWrapper, PageHeading } from "../../components/ui/GlobalStyles";
import PageContainer from "../sharedComponents/PageContainer";
import CustomTable from "../sharedComponents/CustomTable/CustomTable";
import { columns } from "./ActivityData";
import { TableHeader } from "../sharedComponents/CustomTable/CustomTableStyles";
import { ActivityMonitorGetService } from "./services/Appservice";
import { useEffect, useState } from "react";
import { ActivityMonitorRows } from "./AcitityMonitorUtils";
import TableShimmer from "../../components/ui/shimmers/TableShimmerComp";

const ActivityLog = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [rows, setRows] = useState([]);

  useEffect(() => {
    async function fetchData() {
      setIsLoading(true);
      try {
        const response = await ActivityMonitorGetService();
        if (response?.data) {
          const mappedRows = response.data.map((item: ActivityMonitorRows) => {
            const loginTimestamp = parseFloat(item.loginTime);
            const TokenTimestamp = parseFloat(item.tokenGeneratedTime);
            const XTSTimestamp = parseFloat(item.tokenGeneratedTime);

            return {
              id: item.id,
              loginTime: !isNaN(loginTimestamp)
                ? new Date(loginTimestamp * 1000).toLocaleString()
                : "N/A",
              tokenGeneratedTime: !isNaN(TokenTimestamp)
                ? new Date(TokenTimestamp * 1000).toLocaleString()
                : "N/A",
              machineId: item.machineId,
              xtsToken: !isNaN(XTSTimestamp)
                ? new Date(XTSTimestamp * 1000).toLocaleString()
                : "N/A",
            };
          });
          setRows(mappedRows);
          setIsLoading(false);
        } else {
          console.error("No Activity  data found");
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setIsLoading(false);
      }
    }
    fetchData();
  }, []);

  return (
    <>
      <HeadingWrapper>
        <PageHeading>
          <TableHeader>Activity Log</TableHeader>
        </PageHeading>
      </HeadingWrapper>
      {isLoading ? (
        <TableShimmer rowsCount={7} />
      ) : (
        <PageContainer>
          <CustomTable rows={rows} columns={columns} />
        </PageContainer>
      )}
    </>
  );
};

export default ActivityLog;
