export interface ActivityMonitorRows {
    id:number;
    loginTime: string;
    xtsToken: string;
    tokenGeneratedTime:string;
    machineId: string;
  }
  