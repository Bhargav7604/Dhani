export const columns = [
  { field: "id", headerName: "User ID", flex: 1 },
  { field: "loginTime", headerName: "Login Time", flex: 1 },
  { field: "xtsToken", headerName: "Token ", flex: 1 },
  { field: "tokenGeneratedTime", headerName: "Token Time", flex: 1 },
  { field: "machineId", headerName: "IP / Location", flex: 1 },
];
