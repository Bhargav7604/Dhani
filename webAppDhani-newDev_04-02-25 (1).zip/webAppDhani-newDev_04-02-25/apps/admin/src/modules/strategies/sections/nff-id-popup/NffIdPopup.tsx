import React from "react";
import { Modal, Backdrop, Fade } from "@mui/material";
import { useForm, SubmitHandler } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
// import axios from "axios";

import { TableContainer } from "../../../user-list/UsersStyles";
import { ActiveStrategyManageProps } from "../../StrategiesUtils";
import { AdminStyledForm } from "../../../../components/ui/GlobalStyles";
import { NFFFormFields } from "./Nff-id-InputSpecs";
import AdminInputComp from "../../../../components/admininput/AdminInputComp";
import { z } from "zod";
import { CustomButton } from "../../../../styles/FormStyles";

const nffSchema = z.object({
  nffid: z.string(),
});
type NFFSchemaZod = z.infer<typeof nffSchema>;

const NffIdDetails: React.FC<ActiveStrategyManageProps> = ({
  open,
  onClose,
  
}) => {
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<NFFSchemaZod>({
    resolver: zodResolver(nffSchema),
  });

  const onSubmit: SubmitHandler<NFFSchemaZod> = async (data) => {
    // try {
    //   const response = await axios.post(
    //     "https://jsonplaceholder.typicode.com/posts",
    //     data
    //   );
    //   if (response.status === 201) {
    //     console.log("Profile updated:", response.data);
    //     onClose(); // Optional: close modal on success
    //   } else {
    //     console.log("Profile update failed:", response);
    //   }
    // } catch (error) {
    //   console.error("Error during profile update", error);
    // }
    console.log(data);
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      closeAfterTransition
      slots={{ backdrop: Backdrop }}
      slotProps={{ backdrop: { timeout: 500 } }}
    >
      <Fade in={open}>
        <TableContainer>
          <AdminStyledForm onSubmit={handleSubmit(onSubmit)}>
            {NFFFormFields.map((field) => (
              <AdminInputComp
                key={field.name}
                name={field.name}
                control={control}
                heading={field.heading}
                type={field.type}
                placeholder={field.placeholder}
                error={errors[field.name as keyof NFFSchemaZod]?.message}
              />
            ))}

            {/* Submit button */}
            <CustomButton
              type="submit"
              profile
              variant="contained"
              onClick={() => {
                onClose();
              }}
            >
              Update
            </CustomButton>
          </AdminStyledForm>
        </TableContainer>
      </Fade>
    </Modal>
  );
};

export default NffIdDetails;
