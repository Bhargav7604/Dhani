import React, { useState } from "react";
import { Backdrop, Fade,  Modal } from "@mui/material";
import { TableContainer } from "../../../user-list/UsersStyles";
import { ActiveStrategyManageProps } from "../../StrategiesUtils";
import { ButtonWraper, CustomButton } from "../../../../styles/FormStyles";
import {
  FlexProfileDiv,
  StyledSubTitle,
} from "../../../../components/ui/GlobalStyles";
import NffIdManage from "../nff-id-popup/NffIdPopup";


// Assuming you already have StrategySchemaZod defined somewhere
const ApprovedManage: React.FC<ActiveStrategyManageProps> = ({
  open,
  onClose,
  id
}) => {
  const [isNffModalOpen, setIsNffModalOpen] = useState(false);

  const handleCloseModal = () => {
    setIsNffModalOpen(false);
  };
  const handleOpenNFFModal = () => {
    setIsNffModalOpen(true);
  };
  //   const onSubmit: SubmitHandler<any> = async (data) => {
  //     // Handle submit logic here
  //   };

  return (
    <>
      <Modal
        aria-labelledby="transition-modal-title"
        aria-describedby="transition-modal-description"
        open={open}
        onClose={onClose}
        closeAfterTransition
        slots={{ backdrop: Backdrop }}
        slotProps={{ backdrop: { timeout: 500 } }}
      >
        <Fade in={open} style={{ outline: "none", backgroundColor: "white" }}>
          <TableContainer>
            <FlexProfileDiv $flexDirection>
              <FlexProfileDiv $flexDirection>
                <StyledSubTitle>Approve </StyledSubTitle>
                <p>Do you want to Approve this Strategy  </p>
                
              </FlexProfileDiv>

              {/* Buttons */}
              <ButtonWraper>
                <CustomButton variant="outlined" onClick={onClose}>
                  Cancel
                </CustomButton>

                <CustomButton
                  profile
                  variant="contained"
                  onClick={() => {
                    console.log("Confirm clicked");
                    handleOpenNFFModal();
                    onClose();
                  }}
                >
                  Confirm
                </CustomButton>
              </ButtonWraper>
            </FlexProfileDiv>
          </TableContainer>
        </Fade>
      </Modal>
      <NffIdManage open={isNffModalOpen} onClose={handleCloseModal} id={id} />
    </>
  );
};

export default ApprovedManage;

// import React, { useState } from "react";
// import { Backdrop, Fade,  Modal } from "@mui/material";
// import { TableContainer } from "../../../user-list/UsersStyles";
// import { ActiveStrategyManageProps } from "../../StrategiesUtils";
// import { ButtonWraper, CustomButton } from "../../../../styles/FormStyles";
// import {
//   FlexProfileDiv,
//   StyledSubTitle,
// } from "../../../../components/ui/GlobalStyles";
// import NffIdManage from "../nff-id-popup/NffIdPopup";

// const ApprovedManage: React.FC<ActiveStrategyManageProps> = ({
//   open,
//   onClose,
// }) => {
//   const [isNffModalOpen, setIsNffModalOpen] = useState(false);
//   const [scope, setScope] = useState<'global' | 'selected'>('global');

//   const handleCloseModal = () => {
//     setIsNffModalOpen(false);
//   };

//   const handleOpenNFFModal = () => {
//     setIsNffModalOpen(true);
//   };

//   return (
//     <>
//       <Modal
//         aria-labelledby="transition-modal-title"
//         aria-describedby="transition-modal-description"
//         open={open}
//         onClose={onClose}
//         closeAfterTransition
//         slots={{ backdrop: Backdrop }}
//         slotProps={{ backdrop: { timeout: 500 } }}
//       >
//         <Fade in={open} style={{ outline: "none", backgroundColor: "white" }}>
//           <TableContainer>
//             <FlexProfileDiv flexDirection>
//               <StyledSubTitle>Assign</StyledSubTitle>
//               <p>Do you want to assign this strategy?</p>

//               <div>
//       <label>
//         <input
//           type="radio"
//           name="userScope"
//           value="global"
//           checked={scope === 'global'}
//           onChange={() => setScope('global')}
//         />
//         Global Users
//       </label>

//       <label style={{ marginLeft: '1rem' }}>
//         <input
//           type="radio"
//           name="userScope"
//           value="selected"
//           checked={scope === 'selected'}
//           onChange={() => setScope('selected')}
//         />
//         Selected Users
//       </label>

      
//     </div>

//               <ButtonWraper>
//                 <CustomButton variant="outlined" onClick={onClose}>
//                   Cancel
//                 </CustomButton>

//                 <CustomButton
//                   profile
//                   variant="contained"
//                   onClick={() => {
//                     handleOpenNFFModal();
//                     onClose();
//                   }}
//                 >
//                   Confirm
//                 </CustomButton>
//               </ButtonWraper>
//             </FlexProfileDiv>
//           </TableContainer>
//         </Fade>
//       </Modal>

//       <NffIdManage open={isNffModalOpen} onClose={handleCloseModal} />
//     </>
//   );
// };

// export default ApprovedManage;

