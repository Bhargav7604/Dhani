export const NffIDFields = {
    NFF_ID: "nffid",
   

  };
  export const ActiveStrategyFieldMapping = {
    [NffIDFields.NFF_ID]: {
      name: "nffid",
      type: "text",
      placeholder: "NFF Id",
      heading: "NFF ID ",
    },
   
  };
  export const NFFFormFields = [
    ActiveStrategyFieldMapping[NffIDFields.NFF_ID],
   

  ];
  