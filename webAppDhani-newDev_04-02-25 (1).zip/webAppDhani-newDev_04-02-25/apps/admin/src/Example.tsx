const Example = () => {
  alert("This is an alert!");
  return <div>Hello, Admin!</div>;
};

export default Example;
