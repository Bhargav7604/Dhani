export interface WelcomeModalPostBody {
    payload: {
        clientId?: string;
        termsConditions?: boolean;
    }
}