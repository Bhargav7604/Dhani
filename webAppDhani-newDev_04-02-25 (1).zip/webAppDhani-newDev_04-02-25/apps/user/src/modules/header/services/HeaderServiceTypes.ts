export interface ExitAllProps {
  payload: {
    userId: string;
  };
}
