

export const HeaderNavigationData = [
  {
    AlgoTitle: "Deployed Strategies",
    path: "/deployedstrategies",
  },
  {
    AlgoTitle: "Ready to Deploy Strategy",
    path: "/readytodeploy",
  },
  {
    AlgoTitle: "No Code Strategy Builder (DIY)",
    path: "/nocodestrategybuilder",
  },
  {
    AlgoTitle: "Performance Analytics",
    path: "/peformanceanalytics",
  },
  {
    AlgoTitle: "Order Dashboard",
    path: "/orderreports",
  },
];
