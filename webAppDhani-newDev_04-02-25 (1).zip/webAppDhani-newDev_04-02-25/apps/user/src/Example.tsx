const Example = () => {

  return <div>Hello, User!</div>;
};

export default Example;
