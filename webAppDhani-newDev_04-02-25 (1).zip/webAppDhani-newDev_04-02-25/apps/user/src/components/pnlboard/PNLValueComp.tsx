import React, { useState, useEffect } from "react";
import {
  DetailsValueDiv,
  StyledNoDataText,
} from "../../modules/readytodeploy/ReadyToDeployStyles";
import { useAppSelector } from "../../store/Store";
import {
  Detailswrap,
  FlexRowDiv,
  StyledTertiaryText,
} from "../ui/GlobalStyles";
import PnlLogo from "../../assets/svgs/pnl-logo.svg";
import { StyledLogoutImg } from "../../modules/header/HeaderStyles";
import { OpenPositionsResponse } from "../../modules/deployedstrategies/services/SocketDataUtils";
import WebSocketComponent from "../websocet/WebSocket";
import { PNLShimmer } from "../shimmers/PnlBoardShimmer";
import { useMediaQuery } from "@mui/material";
import HoverToFullValues from "../hoverfullvalues/HoverToFullValues";

const PNLValuesComp: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const matches = useMediaQuery("(min-width: 769px)");

  const { socketData } = useAppSelector((appstate) => appstate.socket);
  const isSocketDataValid = (
    data: typeof socketData
  ): data is OpenPositionsResponse => {
    return data !== null && !Array.isArray(data);
  };

  useEffect(() => {
    {
      socketData && setLoading(false);
    }
  }, [socketData]);
  return (
    <>
      <WebSocketComponent />
      {loading ? (
        <PNLShimmer $height={matches ? "60px" : "190px"} $width="100%" />
      ) : (
        <FlexRowDiv $width="100%" $background="#fff" $marginBottom={true}>
          <Detailswrap $background="#fff">
            <DetailsValueDiv $flexdirection="row" $firstchild="true">
              <StyledLogoutImg src={PnlLogo} alt="onl-logo" />
              <StyledTertiaryText $firstchild="true" style={{ color: "white" }}>
                P&L Values
              </StyledTertiaryText>
            </DetailsValueDiv>
            <DetailsValueDiv $iseven="true">
              <StyledTertiaryText>Deployed Capital</StyledTertiaryText>
              {isSocketDataValid(socketData) &&
              socketData?.deployedCapital != null ? (
                <HoverToFullValues
                  value={socketData.deployedCapital}
                  $ispnl
                  $isrupee
                  $isformat
                ></HoverToFullValues>
              ) : (
                <StyledNoDataText>--</StyledNoDataText>
              )}
            </DetailsValueDiv>
            <DetailsValueDiv $iseven="true">
              <StyledTertiaryText>Positional P&L</StyledTertiaryText>
              {isSocketDataValid(socketData) &&
              socketData?.postionalPAndL != null ? (
                <HoverToFullValues
                  value={socketData.postionalPAndL}
                  $ispnl
                  $isrupee
                  $isformat
                ></HoverToFullValues>
              ) : (
                <StyledNoDataText>--</StyledNoDataText>
              )}
            </DetailsValueDiv>

            <DetailsValueDiv $iseven="true">
              <StyledTertiaryText>Intraday P&L</StyledTertiaryText>
              {isSocketDataValid(socketData) &&
              socketData?.intradayPAndL != null ? (
                <HoverToFullValues
                  value={socketData.intradayPAndL}
                  $ispnl
                  $isrupee
                  $isformat
                ></HoverToFullValues>
              ) : (
                <StyledNoDataText>--</StyledNoDataText>
              )}
            </DetailsValueDiv>
            <DetailsValueDiv $iseven="true">
              <StyledTertiaryText>Today's P&L</StyledTertiaryText>
              {isSocketDataValid(socketData) &&
              socketData?.todaysPAndL != null ? (
                <HoverToFullValues
                  $isrupee
                  value={socketData.todaysPAndL}
                  $ispnl
                  $isformat
                ></HoverToFullValues>
              ) : (
                <StyledNoDataText>--</StyledNoDataText>
              )}
            </DetailsValueDiv>
            <DetailsValueDiv $iseven="true">
              <StyledTertiaryText>Overall P&L</StyledTertiaryText>
              {isSocketDataValid(socketData) &&
              socketData?.overAllUserPAndL != null ? (
                <HoverToFullValues
                  $isrupee
                  value={socketData.overAllUserPAndL}
                  $ispnl
                  $isformat
                ></HoverToFullValues>
              ) : (
                <StyledNoDataText>--</StyledNoDataText>
              )}
            </DetailsValueDiv>
          </Detailswrap>
        </FlexRowDiv>
      )}
    </>
  );
};

export default PNLValuesComp;
