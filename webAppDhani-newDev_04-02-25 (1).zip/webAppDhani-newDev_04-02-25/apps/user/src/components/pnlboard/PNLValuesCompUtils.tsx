export interface PNLValuesStateType {
    selectedOption: string;
    activeIndex: number;
  }
  
  export interface PNLValuesCompProps {
    positionalData: { title: string; Value: string; OldValue: number }[];
    intradayData: { title: string; Value: string; OldValue: number }[];
  }
  