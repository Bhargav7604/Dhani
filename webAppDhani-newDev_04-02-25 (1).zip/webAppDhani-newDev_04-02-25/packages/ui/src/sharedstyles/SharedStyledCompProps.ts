export interface StyledParaProps {
    $fontsize?: string;
    $fontweight?: string;
    $color?: boolean;
    $textalign?:string;
    $marginbottom?: string
    $mobilenowrap?: boolean | string;
  }