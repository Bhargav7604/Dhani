import {
  StyledToggleButton,
  StyledToggleButtonGroup,
  ToggleDiv,
  DIYHeaderDiv,
} from "./FormFieldsStyles.js";
import { ToggleItemProps } from "./FormFieldsUtils.js";
import {
  DiyTextHeader,
  ColumnFlexDiv,
} from "../../../../../apps/user/src/components/ui/GlobalStyles.js";
import { MandatoryMark } from "../../sharedstyles/SharedStyledComps.js";
import { ErrorText } from "../../sharedstyles/SharedStyledComps.js";
import React, { useEffect } from "react";
import InfoComp from "../info/InfoComp.js";
import { useAppSelector } from "../../../../../apps/user/src/store/Store.js";
// import { useAppSelector } from "../../../store/Store";

const NoCodeToggleComp = React.forwardRef<HTMLDivElement, ToggleItemProps>(
  ({ heading, item, error, required, info, disabled, ...rest }: ToggleItemProps, ref) => {
    const { value, onChange } = rest;
    const { isLive } = useAppSelector((appState) => appState.welcomePopup);

    // Find the first non-disabled key
    const getValidDefaultKey = () => {
      for (const i of item) {
        if (!(i?.key === "LiveTrading" && !isLive)) {
          return i?.key;
        }
      }
      return null; // fallback if all are disabled
    };

    const toggleValue = value ?? getValidDefaultKey() ?? "";

    // const getValidDefaultKey = () => {
    //   if (!Array.isArray(item)) return null;

    //   for (const i of item) {
    //     if (!(i?.key === "LiveTrading" && !isLive)) {
    //       return i?.key;
    //     }
    //   }

    //   return null;
    // };

    // const toggleValue =
    //   value ?? (Array.isArray(item) ? getValidDefaultKey() : "") ?? "";

    useEffect(() => {
      if (!value) {
        const validKey = getValidDefaultKey();
        if (validKey) {
          onChange?.(validKey);
        }
      }
    }, [value, item, isLive, onChange]);

    return (
      <ColumnFlexDiv ref={ref}>
        <DIYHeaderDiv>
          {heading && (
            <DiyTextHeader>
              {heading} {required && <MandatoryMark>*</MandatoryMark>}
            </DiyTextHeader>
          )}

          {info && <InfoComp info={info} />}
        </DIYHeaderDiv>
        <ToggleDiv>
          <StyledToggleButtonGroup
            aria-label="order info"
            exclusive
            // disabled={true}
            value={toggleValue} // Use the value or default value
            onChange={(_, newValue) => {
              if (onChange) {
                onChange(newValue);
              }
            }}
            disabled={disabled}
          >
            {item?.map(({ key, val }, index) => (
              <StyledToggleButton
                // style={{border:"1px solid blue"}}
                key={index}
                value={key}
                disabled={key === "LiveTrading" && !isLive}
                // The 'active' prop is controlled by the value selected
                $active={toggleValue === key}
              >
                {val}
              </StyledToggleButton>
            ))}
          </StyledToggleButtonGroup>
        </ToggleDiv>
        {/* Display error if there is no selection */}
        {error && <ErrorText style={{ color: "red" }}>{error}</ErrorText>}
      </ColumnFlexDiv>
    );
  }
);

export default NoCodeToggleComp;
